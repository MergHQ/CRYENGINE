#! /bin/sh

cd tests

./run_tests.py $@

exit $?

