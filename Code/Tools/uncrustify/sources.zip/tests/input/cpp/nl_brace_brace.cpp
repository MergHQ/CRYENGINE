
SHOW_VAR status_vars[]= { { "Aborted_clients", (char *)&aborted_threads,
SHOW_LONGLONG, } };

SHOW_VAR status_vars[]= 
{ 
{ "Aborted_clients", (char *)&aborted_threads,
SHOW_LONGLONG, } 
};

SHOW_VAR status_vars[]= 
{ 
{ 
"Aborted_clients", (char *)&aborted_threads,
SHOW_LONGLONG, 
} 
};

