enum class A
{
a,
b
}

class B {
private:
   int x;
}
enum C
{
a,
b
}
