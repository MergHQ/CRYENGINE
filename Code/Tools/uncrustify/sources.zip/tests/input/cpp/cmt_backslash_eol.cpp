foo();
// test \
blah();
bar();
