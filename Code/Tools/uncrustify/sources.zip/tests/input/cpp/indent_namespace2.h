namespace ns1 {
namespace ns2 {
namespace ns3{

	using namespace foo::os;

   class foo2
   {
      int i2;
   };
	}
	}
}
