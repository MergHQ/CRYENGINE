   TestId::TestId( char* name ) :
      n_( ( char* )name )
   {
      n_( (char*)name );
   }

