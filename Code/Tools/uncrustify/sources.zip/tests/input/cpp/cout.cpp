void foo()
{
   cout.setf(ios::showpoint);
   cout.setf(ios::floatfield,ios::fixed);

   what.the.hell.cout << "hello"
      << "world!"
      << "This"
      << "is a"
      << "test!";

   *aaaaaa = (bbbbb(cccccPtr->ddd) & YYYYYYYYYYYYYYYYYYYYYYYY) |
             ((bbbbb(cccccPtr->nnnnnnnn) << ZZZZZZZZZZZZZZZZZZZZZZZZZZZ)
             & WWWWWWWWWWWWWWWWWWWWWWWWWW) | ((bbbbb(cccccPtr->hhhhhhhhhhhhhh)
                       << FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF)
             & EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE);
}
