//comment
void argvInter( int argc, char* argv[], Config * config );
