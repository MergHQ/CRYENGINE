enum MyEnum {
    kOne   = 0,
    kTwo   = 1 << 0,
    kThree = 1 << 1,
    kFour  = 1 << 2
};

