typedef std::list<StreamedData*>::iterator iterator;
double foo()
{
 if (a<bar()> c)
{
throw int();
return(double());
}
 call_a_function(42,
                   double(-1),
                    "charray");
return(foo(n));
}
