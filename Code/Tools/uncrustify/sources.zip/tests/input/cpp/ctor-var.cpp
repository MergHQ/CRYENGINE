int foo()
{
   TextBody textbody(GetBody().GetText());
}
