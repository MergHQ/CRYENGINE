int 
a, b, c;

int d, 
e, f;

void bar(void)
{
   struct foobar
a = { 'x', 0 };
   struct foobar
b = { 'y', 2 },
c = { 'z', 4 };
   struct foobar d = { 'y', 2 },
e = { 'z', 4 };
}
