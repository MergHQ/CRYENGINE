void f()
{
toto
foo1(int);    
toto
foo2(bar);
int
foo3;
}
